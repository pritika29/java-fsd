package com.example;

import java.beans.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InsertRecord
 */
@WebServlet("/InsertRecord")
public class InsertRecord extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertRecord() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			//Read all values from HTML Page
			int rollno=Integer.parseInt(request.getParameter("txtRollno"));
			String name=request.getParameter("txtName");
			Float marks=Float.parseFloat(request.getParameter("txtMarks"));
			
			//Call Connection Method
			Connection con=DBConnection.getConnection();
			//Create Statement Object
			Statement stmt=(Statement) con.createStatement();
			//Create query
			String query="insert into Student(rollno,sname,marks) values("+rollno+",'"+name+"',"+marks+")";
			
			//execute query
			int ans=((java.sql.Statement) stmt).executeUpdate(query);
			PrintWriter out=response.getWriter();
			if(ans>0)
				out.println("Record Inserted");
			else
				out.println("Record not inserted");
			
		}catch(Exception e) {
			e.printStackTrace();}
		}

}