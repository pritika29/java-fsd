package com.retrieval;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FetchData
 */
@WebServlet("/FetchData")
public class FetchData extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

			try {
				response.setContentType("text/html");
				//Step 1: load driver in memory
				Class.forName("com.mysql.cj.jdbc.Driver");
				//Step 2: Connection with database
				Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/Product","root","Pritikatrainee@29");
				PreparedStatement ps=conn.prepareStatement("select * from Product");
				ResultSet rs=ps.executeQuery();
				PrintWriter out=response.getWriter(); 
				out.println("<html><body><table border='1'><tr><td><Product_ID</td><td>P_name</td><td>Product_cost</td></tr>");
				while(rs.next()) {
					out.println("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td></tr>");
			}
				out.println("</table></form></center></body></html>");	
			}
				catch(Exception e) {
				e.printStackTrace();}}}

