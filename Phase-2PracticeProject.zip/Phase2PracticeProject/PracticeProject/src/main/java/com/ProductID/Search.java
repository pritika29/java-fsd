// Retrieving the Product Details Using the Product ID.
// 3. Demonstrate Connection, Statement, and ResultSet in JDBC.
package com.ProductID;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.protocol.Resultset;


@WebServlet("/Search")
public class Search extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Search() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		int Product_ID = Integer.parseInt(request.getParameter("Product_ID"));
		try {
			//Step 1: load driver in memory
			Class.forName("com.mysql.cj.jdbc.Driver");
			//Step 2: Connection with database
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Product","root","Pritikatrainee@29");
			PreparedStatement ps=con.prepareStatement("select * from Product where Product_ID = ?");
			ps.setInt(1, Product_ID);
			out.println("<table width=70% border=1>");
			out.println("<caption>Product Detail: </caption>");
			ResultSet rs=ps.executeQuery();
			ResultSetMetaData rsmd= rs.getMetaData();
			int totalColumn = rsmd.getColumnCount();
			out.println("<tr>");
			for(int i=1; i<=totalColumn; i++) {
				out.println("<th>"+rsmd.getColumnName(i)+"</th>");
			}
			out.println("<tr");
			while(rs.next()) {
				out.println("<tr><td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td></tr>");

			}
			out.println("</table");		
	
		}
		catch(Exception e){
			out.println(e);		;
	
	}

}}
