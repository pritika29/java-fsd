package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Drop
 */
@WebServlet("/Drop")
public class Drop extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Drop() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			//Read all values from HTML Page
		
			
			//Call Connection Method
			Connection con=DBConnection.getConnection();
			
			         Statement stmt = con.createStatement();
			       		      
			         String sql = "DROP TABLE Product1";
			         stmt.executeUpdate(sql);
			         System.out.println("Table deleted in given database...");   	  
			      } 
			       catch (Exception e) {
			         e.printStackTrace();
			      } 
			   }}