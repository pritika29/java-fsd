package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Select
 */
@WebServlet("/Select")
public class Select extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Select() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			int Product_ID=Integer.parseInt(request.getParameter("Product_ID"));
			//Call Connection method
			Connection con=DBConnection.getConnection();
			//Create query
			String query="select * from Product1 where Product_ID=?";
			//Create Statement Object
			PreparedStatement psmt=con.prepareStatement(query);
			psmt.setInt(1, Product_ID);
		
					
			//execute query
			ResultSet rs=psmt.executeQuery();

			//display result in html page
			PrintWriter out=response.getWriter();
			out.println("<table border=2>");
			out.println("<tr>"
					+ "<th>Product_ID</th>"
					+ "<th>P_name</th>"
					+ "<th>Product_cost</th>"
					+ "</tr>");
			while(rs.next()) {
				out.println("<tr>");
				out.print(	"<td>"+rs.getInt("Product_ID")+"</td>");
				out.print("<td>"+rs.getString("P_name")+"</td>");
				out.print("<td>"+rs.getFloat("Product_cost")+"</td>");
				out.println("</tr>");
			}
			out.println("</table>");
			con.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}