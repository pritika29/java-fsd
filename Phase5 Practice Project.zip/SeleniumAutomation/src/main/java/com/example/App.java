package com.example;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class App 
{
    public static void main( String[] args )
    {
       // register chrome driver 
    	System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Downloads\\chromedriver-win32 (1)\\chromedriver-win32\\chromedriver.exe");
    //create an object to the driver to access the browser componenets 
    	WebDriver wd=new ChromeDriver();
    	//maximize the browser 
    	wd.manage().window().maximize();
    	//to open web url -> localhost , www.
    	wd.get("https://www.amazon.in/");
    	wd.findElement(By.linkText("Start here.")).click();
        wd.findElement(By.id("ap_customer_name")).sendKeys("Pritika");
    	wd.findElement(By.id("ap_phone_number")).sendKeys("1234566789");
    	wd.findElement(By.id("ap_email")).sendKeys("P@s.c");
    	wd.findElement(By.id("ap_password")).sendKeys("123456789");
    	wd.findElement(By.id("continue")).click();
    }
}

