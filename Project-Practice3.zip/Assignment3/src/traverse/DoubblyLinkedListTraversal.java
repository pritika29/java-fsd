//7.Write a program in Java to traverse a doubly linked list in the forward and backward directions
package traverse;
import java.util.*;
import java.lang.*;
 
// Java program to implement all functions
// used in Doubly Linked List
 
// Node for Doubly Linked List
class node1{
    int key;
    node1 prev;
    node1 next;
    node1(){
        prev = null;
        next = null;
    }
}
 
class Node2{
    static node1 head = null;
    static node1 first = null;
    static node1 tail = null;
    static node1 temp = null;
    static int i = 0;
    // Function to add a node in the
    // Doubly Linked List
    static void addnode(int k)
    {
     
        // Allocating memory
        // to the Node ptr
        node1 ptr = new node1();
     
        // Assign Key to value k
        ptr.key = k;
     
        // Next and prev pointer to NULL
        ptr.next = null;
        ptr.prev = null;
     
        // If Linked List is empty
        if (head == null) {
            head = ptr;
            first = head;
            tail = head;
        }
     
        // Else insert at the end of the
        // Linked List
        else {
            temp = ptr;
            first.next = temp;
            temp.prev = first;
            first = temp;
            tail = temp;
        }
     
        // Increment for number of Nodes
        // in the Doubly Linked List
        i++;
    }
     
    // Function to traverse the Doubly
    // Linked List
    static void traversing()
    {
        // Nodes points towards head node
        node1 ptr = head;
     
        // While pointer is not NULL,
        // traverse and print the node
        while (ptr != null) {
     
            // Print key of the node
            System.out.print( ptr.key+" ");
            ptr = ptr.next;
        }
        System.out.println();
    }}



