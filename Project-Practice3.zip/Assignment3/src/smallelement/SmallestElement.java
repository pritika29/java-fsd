//2.Write a program in Java to find the fourth smallest element in an unsorted list
package smallelement;
import java.util.Collections;
import javax.lang.model.type.ArrayType;
class SmallestElement {
	public static int smalletst(int[] m, int n ) {
		//sort the array
		return m[n-1];
	}
	//driver's code
	public static void main(String[] args) {
		int m[]= new int[]{20,40,3,8,2,1,4};{
			int n =5;
			//function call
			 System.out.print("smallest element in the unsorted array "
                   + smalletst(m,n));	
		}	
	}}
