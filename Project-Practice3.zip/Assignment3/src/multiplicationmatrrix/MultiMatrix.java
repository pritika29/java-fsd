// 4.Write a program in Java to multiply two matrices
package multiplicationmatrrix;

public class MultiMatrix {
//main class
	public static void main(String[] args) {
		//create two matrices 3*3 arrays
		int p[][]= {{1,2,3},{4,5,6},{7,8,9}};
		int q[][]= {{1,2,3},{4,5,6},{7,8,9}};	
// create a matrix in which the multiplication result will be stored 
		int r[][]=new int[3][3];
		// multiplying both the matrices we will get 
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) 
		{
				r[i][j]=0;
				for(int k=0;k<3;k++)    
				{    
				r[i][j]+=p[i][k]*q[k][j];
		}
				System.out.print(r[i][j]+" ");
		} System.out.println();

	}
}}
