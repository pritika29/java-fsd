//8.Write a program in Java to insert and remove elements in a stack
//stack follows LIFO property i.e., last-in-first-out
package stackInsertDelete;
import java.util.*;
import java.io.*;
public class StackInsertDelete {

	public static void main(String[] args) {
		//INSERTION IN STACK
		// default initializing 
		Stack<String> stack = new Stack<String>();
		//push the elements in stack
		stack.push("10");
	    stack.push("Twenty");
	    stack.push("30");
	    stack.push("Forty");
	    stack.push("50");
	    stack.push("Sixty");
	    
	    //print the output
	    System.out.println("STACK OBTAINED AFTER CREATION= " +stack);
	    
	    //REMOVING IOR DELETION OF ELEMNTS FROM STACK IT FOLLOWS LIFO PROPERTY 
	    System.out.println("Popped element: " + stack.pop());
	    
	    // Displaying the Stack after pop operation
	    System.out.println("After removing element from stack the obtained stack= " + stack);
	    
	
}}