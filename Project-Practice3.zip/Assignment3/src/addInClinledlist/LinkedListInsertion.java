//6.Write a program in Java to insert a new element in a sorted circular linked list
package addInClinledlist;
import java.lang.*;
public class LinkedListInsertion {
	public static void main(String[] args) {
		LinkedListInsertion Obj = new LinkedListInsertion();
        Obj.insertEnd(55);
        Obj.insertEnd(57);
        Obj.insertEnd(58);
        Obj.insertEnd(59);
        
        Obj.print();
    }
		// for node 
		public class Node{
	        int element;
	        Node next;
	        public Node(int element) {
	            this.element = element;
	        }
	    }
//for head and tail for the process of insertion
	    public Node head = null;
	    public Node tail = null;
	    int size=0;

	    public void insertEnd(int element){
	        Node newEle = new Node(element);
	        if(head == null) {
	            head = newEle;
	            tail = newEle;
	            newEle.next = head;
	        }
	        else {
	            tail.next=newEle;
	            newEle.next=head;
	            tail=newEle;
	        }
	        size++;
	    }

	    public void print() {  //print function
	        Node current = head;
	        if(head == null) {
	            System.out.println("List is empty");
	        }
	        else {
	            System.out.println("Nodes of the circular linked list: ");
	            do{
	                System.out.print(" "+ current.element);
	                current = current.next;
	            }while(current != head);
	            System.out.println();
	        }
	    }
	}


