//9.Write a program in Java to insert and remove elements in a queue
//it foloows FIFO propert i.e., first in first out
package queueInsertDelete;
import java.util.Queue;
import java.util.Stack;
import java.util.Deque;
import java.util.PriorityQueue;;
public class QueueInsertDelete {
	public static void main(String[] args) {
		//INSERTION IN STACK
				// default initializing 
				Queue<String> queue = new PriorityQueue<String>();
				//push the elements in stack
				queue.add("Suresh");
				queue.add("jay");
				queue.add("Ramesh");
				queue.add("vijay");
				queue.add("Naresh");
				queue.add("Ajay");
			    
			    //print the output queue
			    System.out.println("QUEUE OBTAINED AFTER CREATION= " +queue);
			    
			    //REMOVING IOR DELETION OF ELEMNTS FROM queue from front
			    String front = queue.remove();
			    System.out.println("REMOVED element: " + front);
			    
			    // Displaying the queue after pop operation
			    System.out.println("After removing element from queue the obtained Queue= " + queue);
			    
			
		}

	}


