//1.Write a program in Java to right rotate an array by 5 steps
package arrayrotate;

public class RotateArray {
	public static void main (String[]args) {
	//initilializing array 
	int a[]= {8,7,6,5,4,3,2,1};
	////TO ROTATE IT BY 5 steps ////
	 int n=5;
	 /// show original array
	 System.out.println("Original Array before Rotation= ");
	 for(int i=0;i<a.length;i++) {
		 System.out.println(a[i]+" ");
	 }// rotating array by n times length
	 for(int i=0;i<n;i++) {
		 int k, last ;
		 //store array if element
		 last = a[a.length-1];    
         
         for(k = a.length-1; k > 0; k--){    
             //Shift element of array by one    
             a[k] = a[k-1];    
         }    
         //Last element of array will be added to the start of array.    
         a[0] = last;    
     }    
     System.out.println();    
     System.out.println("After performing Rotation= " );
     for(int i=0;i<a.length;i++){    
         System.out.print(a[i]+" ");   
     }}}
	
    