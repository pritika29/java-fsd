//3.Write a program in Java to find the sum of n number of elements in the range of L and R where 0 <= L <= R <= n-1
package sumOfnNumbers;
public class SumOfNnumbers {
	static int sumOfn(int n) {
		int sum=(n*(n+1))/2;
		return sum;
	}//retutn sum of all numbers in range L and R
	static int range(int l, int r) {
		return sumOfn(r)-sumOfn(l-1);
		
	}
//driver's code
	public static void main(String[] args) {
		int l=1,r=10;
		System.out.println("Sum of n natural number in a range between L and R="+range(l,r));

	}

}
