package com.example;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.google.common.collect.Sets;

public class SelTest<Self> {
WebDriver wd=null;

@Before
public void init() {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Downloads\\chromedriver-win32 (1)\\chromedriver-win32\\chromedriver.exe");
    //create an object to the driver to access the browser componenets 
    	wd=new ChromeDriver();
    	//maximize the browser 
    	wd.manage().window().maximize();
wd.get("http://localhost:8083/Seleniumjdbc/index.jsp");
}

	@Test
	public void test1() {
		wd.findElement(By.name("user")).sendKeys("vineet");
		wd.findElement(By.name("submit")).submit();
		String expectedres="inserted successfully";
		String actualvale=wd.findElement(By.name("h1")).getText();
		assertEquals(expectedres, actualvale);
	}
	
	@Test
	public void test2() {
		wd.findElement(By.name("user")).sendKeys("likita");
		wd.findElement(By.name("submit")).submit();
		String expectedres="inserted successfully";
		String actualvale=wd.findElement(By.name("h1")).getText();
		assertEquals(expectedres, actualvale);
	}
	
	@After
	public void close() {
		wd.close();
	}
	}



