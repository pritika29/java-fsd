package com.example;

import org.testng.annotations.Test;

public class SelTest {
  @Test
  public void f() {
  }
}
