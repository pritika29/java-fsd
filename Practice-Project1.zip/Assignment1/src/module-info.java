/**
 * 
 */
/**
 * 
 */
module Assignment1 {
	requires java.xml;
}