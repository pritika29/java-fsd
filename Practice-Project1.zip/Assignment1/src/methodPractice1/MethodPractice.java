// Java to verify implementations of methods and ways of calling a method  

package methodPractice1;
public class MethodPractice {
	
	// Create a checkNumber() method with an integer variable called number

	static void checkNumber(int number) 
	{ 
		
//if number is 25 print it is divisible by 5
		
		if(number<25) {
			System.out.println("it is divisible by 5");
		}
		
//if number is not 25 print not divisible by 5		
		
		else {
			System.out.println("Not divisible by 5");
		}
	}
//making a main class and will call method checkNumber in this class which we made in MethodPractice class
	
	public static void main(String[] args) {
		
// Method calling
		
		checkNumber(30);

	}

}
