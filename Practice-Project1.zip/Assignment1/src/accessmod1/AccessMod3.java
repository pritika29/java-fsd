package accessmod1;

import accessmod.AccessMod1;

public class AccessMod3  extends AccessMod1{


	public static void main(String[] args) {
		
		AccessMod3 c= new AccessMod3();
		System.out.println(c.roll);  
		System.out.println(c.getid());
		

	}

}
