//program in Java to verify the implementation of inner classes
package innerclass;
import java.util.*;

//Class 1
//Helper class
class Innerclasses {

 // Method of helper class
 void show()
 {
     // Print statement
     System.out.println(
         "i am here in show method");
 }
}

//Class 2

class Innerclasses1 {

 //  An anonymous class with Demo as base class
 static Innerclasses d = new Innerclasses() {
     // Method 1
     // show() method
     void show()
     {// Calling method show() via super keyword
         // which refers to parent class
         super.show();

         // Print statement
         System.out.println("i am in Innerclasses1 class");
     }
 };

 // Method 2
 // Main driver method
 public static void main(String[] args)
 {
     // Calling show() method inside main() method
     d.show();
 }
}