package ArthmeticCalculator;
import java.io.*;
import java.lang.*;
import java.lang.Math;
import java.util.Scanner;
public class Calculator {
//main class 
	public Calculator() {
		// TODO Auto-generated constructor stub
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//taking two numbers 
		
		double n1 ,n2;
		//too take input form the user for calculations
		Scanner sc = new Scanner (System.in);
		System.out.println("ENTER THE NUMBERS TO BE CALCULATED \n");
		//take inputs from user choice
		n1=sc.nextDouble();
		n2=sc.nextDouble();
		System.out.println("CHOOSE THE OPERATOR AMONG (+,-,*,/,%,^)\n");
		
		char operate = sc.next().charAt(0);
		double m=0;
		
		switch(operate)
		{
		//for adding two numbers 
		case'+':
			m=n1+n2;
			break;
			//for subtracting two numbers 	
		case'-':
			m=n1-n2;
			break;
			//for dividing two numbers 
		case'/':
			m=n1/n2;
			break;	
			//for modulo of two numbers 
		case'%':
			m=n1%n2;
			break;	
			//for multiplying  two numbers 
		case'*':
			m=n1*n2;
			break;	
		default:
			System.out.println("wrong input");	
		}
		System.out.println("CALCULATED ANSWER OF TWO NUMBERS ");
		System.out.println( );	
	//printing result
		System.out.println(n1+" "+operate+" "+n2 + "=" +m);
	}
}
 