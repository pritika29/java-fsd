//java program for verifying  the implementations of constructor types
// constructors are of two types basically= 1.Parameterized constructor, 2.Default constructor
package construct;

public class ConstructorsType {
	String name;
	int id;
	
//CREATING A PARAMETRIZED CONSTRUCTORS 
    ConstructorsType(int i,String n){  
    id = i;  
    name = n;  
    }  	
//CREATING A DEFAULT CONSTRUCTOR
	ConstructorsType(){}
	void display(){System.out.println(id+" "+name);}  
	public static void main(String[] args) 
	{	
		
//creating objects and passing values  for PARAMETRIZED CONSTRUCTORS
		    ConstructorsType s3= new ConstructorsType(77,"shruti");  
		    ConstructorsType s4 = new ConstructorsType(44,"mohit");  
//calling method to display the values of object  FOR PARAMETRIZED CONSTRUCTORS
		    s3.display();  
		    s4.display(); 
		    
//creating object and passing default values   FOR DEFAULT CONSTRUCTORS 
			ConstructorsType s1=new ConstructorsType();  
			ConstructorsType s2=new ConstructorsType();
//calling method for displaying values of the object  
			s1.display();  
			s2.display(); 

	}

}
