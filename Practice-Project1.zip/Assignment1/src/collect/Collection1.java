// program in Java to verify implementations of collections
//collections are the set of predefined classes and interfaces in JAVA
//we are taking array list as it is predefined array_list class in collections framework 

package collect;
import java.util.ArrayList;

public class Collection1 {

	public static void main(String[] args) {
	//we will take array_list which is predefined in collection framework
		ArrayList<String> Name=new ArrayList<String>();
		Name.add("ashu");
		Name.add("ashwini");
		Name.add("neha");
		Name.add("charu");
		//print the names in array
		System.out.println(Name);
		
		//in order to add new name between any array names or index we must do following step
		Name.add(1,"hema");
		System.out.println(Name);
		
		//in order to replace value set is used
		Name.set(0,"Ashish");
		System.out.print(Name);
		
		//in order to remove element from array	
		Name.remove(3);
		System.out.print(Name);
		
		//in order to get only specific name or element from the array 
		System.out.print(Name.get(0));
		
		//in order to clear all elements from array	 at once 
		Name.clear();
		System.out.print(Name);
		

	}}
