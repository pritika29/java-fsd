package arr1;

public class ImplementingArray {

	public static void main(String[] args) {
		//declaring ,initializing array
		int a[]= {1,2,3,4,5,6,7};
		for(int i=0;i<a.length;i++)
			//length is the property of array 
			//print the array
			System.out.println(a[i]);
		
		//to print the element present at particular index
		System.out.println("element present at 5th position or 5th index is = "+a[5]);
		
		// change an array
		a[0] = 9;
		System.out.print("changing value of index 0=\n "+a[0]);
		
		
		//cloning of an array and checking if the will be equal or not
		System.out.println("\ncloned array");
		int b[]= a.clone();
		for(int i=0;i<a.length;i++)
			System.out.println(a[i]);
		
		System.out.println("Both arrays equal or not=");  
		System.out.println(a==b);  
	}
}
/* for creating and performing actions on 2d array which contains row and columns and for( multidimensional array)
 * int matrix[2][3] = { {1, 4, 2}, {3, 6, 8} };
printf("%d", matrix[0][2]); */