package EmailValidation;
import java.util.regex.*;
import java.util.*;
public class EmailValidate {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// EMAIL VERIFICATION USING REGAULAR-EXPRESSION
		// EMAIL VERIFICATION PERMITTED BY RFC 5322//
		
		ArrayList<String>emails = new ArrayList<String>();
		//adding E-mails syntax  which are valid and will be valid after 
		//validation the correct way to wrote an email 
		emails.add("abcdefgZmn@domain.co.in");
		emails.add("12345678@domain.com");
		emails.add("25abcds.name@domain.co.in");
		emails.add("abcdeF.name@domain.com");
		
		// add E-mails which re not valid,of wrong way of writing //
		emails.add("@domain.com");
	
		// USING REGULAR EXPRESSION HERE,//
		
		String regex = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
		
		//now to get the pattern we will compile regular expression
		Pattern pattern = Pattern.compile(regex);
		
		//Iterating email array list//
		for(String email : emails)
		{
			//create instance for matcher//
			
			Matcher matcher = pattern.matcher(email);
			System.out.print(email +":"+matcher.matches()+"\n");
			
		}
	}
}

//similarly for validation various methods using regular expression can be performedby simplest regualr expression 
//adding restriction to user_name etc
