// JAVA program to create strings and display the conversion of string to StringBuffer and StringBuilder.

package conversion;

public class Conversions {

	public static void main(String[] args) {
		//CRREATING STRINGS 1
		String st1="My name is XYZ.";
		//create string buffer object 
		StringBuffer sb= new StringBuffer(); 
		//create string builder object 
		StringBuilder sb1=new StringBuilder();
		//converting String into stringBuffer by append method
		//converting String into stringBuilder by append method
		sb.append(st1);
		sb1.append(st1);
		
		//CRREATING STRINGS 2
				String st2=" I am From Delhi."; 
				//converting String into stringBuffer by append method
				//converting String into stringBuilder by append method
				sb.append(st2);
				sb1.append(st2);
				//Print 
				System.out.println("CONVERSION FROM STRING TO BUFFER"+" using append() method : \n\n" + sb);
				
				System.out.print("\nCONVERSION FROM STRING TO BUILDER"+" using append() method : \n\n" + sb1);
				

	}

}
