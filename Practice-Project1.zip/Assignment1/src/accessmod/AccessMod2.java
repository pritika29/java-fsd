package accessmod;

public class AccessMod2 {

	public static void main(String[] args) {
		AccessMod1 b= new AccessMod1();
		System.out.println(b.roll);  
		System.out.println(b.getid());
		
		
		
		
		
		
	}

}
