package accessmod;
//default is accessible within the package but not outesie the package 
//public is accessible in all outside the package too in this it will be accessible in AccessMod2 package 
//private accessible only in file
//protected ,accessed through subclass when extended or using extended from original!
public class AccessMod1 {

/*protected int id=2,int roll;*/
/*protected int getid() {return id;}*/  ////PROTECTED////
	
	/*int id=2,int roll;*/     
	/* int getid() {return id;}*/   ////DEFAULT///
	
	
	public int id=2;
	public int roll=90;
	
	public int getid() {
		return id;
	}

}
