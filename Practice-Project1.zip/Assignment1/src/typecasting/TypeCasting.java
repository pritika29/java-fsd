//Java to implement implicit and explicit type casting

package typecasting;
import java.util.*;
import java.lang.*;



public class TypeCasting {

	public static void main(String[] args) {
		

		//implicit data conversion (can be done automatically by compiler, conversion from small data type into large data type)
		
				int n1=84;
				float n2=9.84f;
				float sum= n1+n2; //6.0+9.8f
				System.out.println("impilicit type casting =\n"+sum);
		
		//explicit type casting(which can not be done automatically by compiler,conversion from large data type into small data typ) 
				
				int sum1 =(int)(n1+n2);
				System.out.println("explicit type casting =\n"+sum1);
				

	}

}
