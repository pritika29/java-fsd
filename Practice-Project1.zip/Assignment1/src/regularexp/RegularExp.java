//Java program to verify implementations of regular expressions

package regularexp;
import java.util.regex.*;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class RegularExp {
//Pattern class defines a pattern while matcher class is used to search that pattern in RegEx
	public static void main(String[] args) {
	Pattern pattern= Pattern.compile("HelloWorld",Pattern.CASE_INSENSITIVE);
	Matcher matcher = pattern.matcher("HelloWorld GoodMorning");
	boolean matchfound= matcher.find();
//giving a condition 
	if(matchfound)
	{System.out.println("matched");
	}
	else {
		System.out.println("not matched");
	}
//quantifiers examples,u and t are not matching pattern it will give false value
	System.out.println(Pattern.matches("[pmn]+", "ppuutttp"));
	
//quantifiers examples,pritika is matching pattern it will give true value
		System.out.println(Pattern.matches("[pritika]+", "pritika"));

// checking for alphanumeric characters
		//true because characters matches with pattern
		System.out.println(Pattern.matches("[a-zA-Z0-9]{6}","arav23"));

//it will give false because it has more (more than 6 char)  
	System.out.println(Pattern.matches("[a-zA-Z0-9]{6}", "srivastava42"));

		
	}
	
}
