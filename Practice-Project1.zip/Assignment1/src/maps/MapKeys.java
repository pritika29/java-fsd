//a program in Java to verify implementations of maps
//A map contains values on the basis of key, i.e. key and value pair
//we are taking HashMaps for the implementation of Map
package maps;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
public class MapKeys {

	public static void main(String[] args) {
		//creating object for hash_map
		HashMap hm=new HashMap();
		// 	put(object key.object value) is used to insert an entry in the map.
		hm.put(1001, "ashish");
		hm.put(1002, "manish");
		hm.put(1003, "harish");
		hm.put(1004, "shirish");
		System.out.println(hm);
		
		//to remove(object key) It is used to delete an entry for the specified key.
		hm.remove(1002);
		System.out.println("updated HashMap after removal of 1002= "+hm);
		
		//replace() elements ..all key elements with Ajay
				hm.replaceAll((k,v) -> "Ajay");  
				System.out.println("updated elemnts after replacing every key value with ajay=\n"+hm);
		//replace the value with new value in a key
				hm.replace(1001, "Ajay", "Ravi"); 
				System.out.println("after replacing ajay with ravi=\n"+hm);
				
		//Set<Map.Entry<K,V>> entrySet() returns the Set view containing all the keys and values.
		Set set= hm.entrySet();
		//to get separately values and keys using iterator 
		Iterator itr = set.iterator();
		while(itr.hasNext()) {
		System.out.println(itr.next());
		
		
		
		}}}

	
