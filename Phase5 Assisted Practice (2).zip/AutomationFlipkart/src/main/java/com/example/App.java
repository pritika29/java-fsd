package com.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class App 
{
    public static void main( String[] args )
    {
       // register chrome driver 
    	System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Downloads\\chromedriver-win32 (1)\\chromedriver-win32\\chromedriver.exe");
    //create an object to the driver to access the browser componenets 
    	WebDriver wd=new ChromeDriver();
    	//maximize the browser 
    	wd.manage().window().maximize();
    	//to open web url -> localhost , www.
    	wd.get("https://www.flipkart.com/");
    	wd.findElement(By.name("q")).sendKeys("iphone");
    	wd.findElement(By.xpath("/html/body/div[2]/div/div/button")).click();
    	//close the browser
    //	wd.close();
    }
}

