//8.Writing a program in Java implementing the quick sort algorithm
package quicksort;

public class QuickSort {

	public static void main(String[] args) {
		int a[]= {48,57,22,91,10,69,13};
		quickSort(a,0,a.length-1);
		for(int i=0;i<a.length;i++)
			System.out.print(a[i]+" ");

	}

	private static void quickSort(int[] a, int low, int high) {
		if(low<high) {
			//find pivot element such that 
			//element smaller than pivot are on left side
			//element greater than pivot are on right side
			int pivot=partition(a,low,high);
			quickSort(a,low,pivot-1);
			quickSort(a,pivot+1,high);
		}
		
	}

	private static int partition(int[] a, int low, int high) {
		//choose rightmost element as pivot
		int pivot=a[high];
		//pointer for greater value
		int i=low-1;
		//traverse through all element 
		//compare each element with pivot
		for(int j=low;j<high;j++) {
			if(a[j]<=pivot) {
				//if element is smaller than pivot then swap it with greater element pointed by i
				i++;
				//swap element at i with element at j
				int temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		
		}
		//swapping element at i with the element at j
		int temp=a[i+1];
		a[i+1]=a[high];
		a[high]=temp;
		return i+1;
	}}