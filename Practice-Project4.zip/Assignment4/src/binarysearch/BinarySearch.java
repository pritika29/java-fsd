package binarysearch;
import java.util.Scanner;
public class BinarySearch {

	private int nextInt;

	public static void main(String[] args) {
		int a[]= {1,15,16,18,19};
		int x=18,mid;
		int start=0;
        int end=a.length;
        boolean flag=false;
        while(start<=end){
            mid=(start+end)/2;
            if(a[mid]==x){
                flag=true;
                break;
            }
            else if(a[mid]<x)
            start=mid+1;
            else
            end=mid-1;
        }
        if(flag==true)
        System.out.println("Value found at=\n"+x
        		);
        else
        System.out.println("Value not found");
        
}

}
