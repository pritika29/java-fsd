//5.Writing a program in Java implementing the bubble sort algorithm

package bubblesort;

public class BubbleSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		{int temp;
		int a[] = {20,50,60,12,14,1,3,90};
		for(int i=0;i<a.length-1;i++){
		    for(int j=0;j<a.length-1-i;j++){
		      if(a[j]<a[j+1]){
		          temp=a[j];
		          a[j]=a[j+1];
		          a[j+1]=temp;
		      }  
		    }
		}
		//sorted Arrays
		for(int i=0;i<a.length;i++)
		System.out.println(a[i]);
	}

	}

}
