//4.Writing a program in Java implementing the selection sort algorithm
package selectionsort;
import java.util.Arrays;
public class SelectionSort {
	public static void main(String args[])
	//initialize
	{int temp;
	int sec[] = {2, 13, 44, 10, 48, 25, 1, 3, 9};
	for(int i=0;i<sec.length-1;i++){
	    for(int j=i+1;j<sec.length;j++){
	      if(sec[i]<sec[j]){
	          temp=sec[i];
	          sec[i]=sec[j];
	          sec[j]=temp;
	      }  
	    }
	}
	//to get the sorted Arrays
	for(int i=0;i<sec.length;i++)
	System.out.println(sec[i]);
}}