//1.Writing a program in Java implementing the linear search algorithm

package linearsearch;
import java.io.*;
 class LinearSearch {


	public static int Search(int a[], int k, int m)
	{
		for(int l=0; l<k; l++) 
		{
		if(a[l]==m) 
			
		return l;	
	}
		return -1;
	}
	public static void main(String[] args)
	{
		int a[]= {20,60,80,40,50};
		int m= 80;
		
		//call method
		 int searching = Search(a, a.length, m);
		if(searching == -1) 
			System.out.println("element u r searching  is not present in the array");
		
		else 
			System.out.println("Element is present at index number = \n"+searching);
		}
		 

	}


