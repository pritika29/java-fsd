// a program in Java to demonstrate exception handling

package exceptionhandling;

public class ExceptionHandling {

	public static void main(String[] args) {
		//we will use try-catch methods for exception handling 
		System.out.println("taking integers");
		int a=20/20;
		System.out.println("a is divisilbe by 4");
//declare a try , catch block
		try {
			System.out.println("now performing division in next step");
			int b=20/0;//it is a exception case 
			System.out.println("After performing division");
		}
		//for exception handling
		
		catch(ArithmeticException e) 
		{ 
			System.out.println("can not be " +e);
			
		}
		//finally for final statement 
		finally {
			System.out.println("excpetion handling performed ,Divisions done");
		}
	}

}
