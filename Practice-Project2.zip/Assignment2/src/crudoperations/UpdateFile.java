package crudoperations;
import java.io.FileWriter;   

import java.io.IOException;
public class UpdateFile {

	public static void main(String[] args) {
		try {  

	        FileWriter fwrite = new FileWriter("sample1.txt");  

	        fwrite.write(" UPDATING ACTION DONE IN THIS FILE ");   

	        fwrite.close();   

	        System.out.println("UPDATION TO WRITE IS DONE SUCCESSFULLY.");  

	    } catch (IOException e) {  

	            System.out.println("Exception");

	}

}}
