package crudoperations;
import java.io.File;   

public class DeleteFile {

	public static void main(String[] args) {
		// TO delete the sample1 file
		File file= new File("sample1.txt");   
	    if (file.delete()) {   
	      System.out.println(file.getName()+ " file deleted successfully.");  
	    } else {  

	            System.out.println("Error");

	}

}}
