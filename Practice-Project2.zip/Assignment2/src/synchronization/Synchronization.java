//program in Java to demonstrate synchronization

package synchronization;
//writing synchronization keyword for synchronization proccess
public class Synchronization implements Runnable{
	//initializing
	int chocoaltes=4;
    static int p = 1, q = 2, r = 3;
    synchronized void toffees (String name, int wantchocolates)
    {
    	//condition for distribution of chocolate where multi-threads is wantchocolates and chocolates are resources
        if (wantchocolates <= chocoaltes)
        {
            System.out.println (wantchocolates + " given to " + name);
            chocoaltes = chocoaltes - wantchocolates;
        }
        else
        {
            System.out.println ("No chocolate present");
        }
    }
    public void run ()
    {
        String name = Thread.currentThread ().getName ();
        if (name.equals ("b1"))
        {
            toffees (name, p);
        }
        else if (name.equals ("b2"))
        {
            toffees (name, q);
        }
        else
        {
            toffees (name, r);
        }
    }
//main class
	public static void main(String[] args) {
		  Synchronization s = new Synchronization ();
	        Thread t1 = new Thread (s);
	        Thread t2 = new Thread (s);
	        Thread t3 = new Thread (s);
	        t1.setName ("b1");
	        t2.setName ("b2");
	        t3.setName ("b3");
	        t1.start ();
	        t2.start ();
	        t3.start ();

	}

}
