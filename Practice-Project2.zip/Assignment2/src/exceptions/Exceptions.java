//a program in Java to throws, throw, finally, and custom exceptions in Java.

package exceptions;

public class Exceptions
{
		//extends can also be used as a custom exception  when throws is not used 
	    static void met() throws ArithmeticException 
		{
			 System.out.println("Inside the method()");  
		        throw new ArithmeticException("throwing ArithmeticException"); 
		}
			
		//main method
	    public static void main(String[] args) {
		try{
			met();
		}
		//handling exception
		catch (ArithmeticException e) {
			
			System.out.println("exception found in main method()"+e);
			
		//using finally as a final step and printing the final output 	
		}
		finally {
			//finally lets you execute code, after try/catch,throw/throws
			System.out.println("threr are ceratin exceptions");
		}}

}
