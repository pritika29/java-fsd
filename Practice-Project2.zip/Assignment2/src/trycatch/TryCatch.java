//a program in Java to demonstrate try and catch
package trycatch;

public class TryCatch {
//main class
	public static void main(String[] args) {
		//
		try {
			int a[]= {1,2,3,4,5,6,7};
			System.out.println(a[15]);
		}
		////code that may throw an exception to catch it
		//to handle 
		catch(ArrayIndexOutOfBoundsException e){
			//printing the exception line 	
		}
		//final statement 
		System.out.println("Cannot be executed due to some exception");

	}

}
