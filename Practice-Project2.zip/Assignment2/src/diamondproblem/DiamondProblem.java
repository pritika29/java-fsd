// a program in Java to resolve the diamond problem using OOPs’ concepts

//solution to the diamond problem is default methods and interfaces.

package diamondproblem;


	//InterfaceName.super.methodName();  
	interface a{
		public default void display() {
			System.out.println("display methond of a() is invoked");
		}
	}
	interface b{
		public default void display() {
			System.out.println("display methond of b() is invoked");
		}}
	public class DiamondProblem implements a,b{
		public void display(){
			a.super.display();
			b.super.display();
		}
//main class 
	public static void main(String[] args) {
		// object 
		DiamondProblem obj= new DiamondProblem();
		obj.display();

	}
//Interfaces has same method() name and signature but no ambiguity between the methods, both are invoked rightly
}
