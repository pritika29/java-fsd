package FileHandling;
import java.io.FileWriter;   

import java.io.IOException;
public class WriteFile {

	public static void main(String[] args) {
		try {  

	        FileWriter fwrite = new FileWriter("sample1.txt");  

	        fwrite.write("Writing ACTION DONE IN THIS FILE ");   

	        fwrite.close();   

	        System.out.println("wrtitten again.");  

	    } catch (IOException e) {  

	            System.out.println("Exception");

	}

}}

