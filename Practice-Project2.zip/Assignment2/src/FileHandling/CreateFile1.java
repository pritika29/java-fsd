package FileHandling;

import java.io.*;
import java.io.IOException;
import java.io.File;

public class CreateFile1 {

	public static void main(String[] args) {
		//CREATING a File
		try {
			File file = new File("sample1.txt"); 
			if (file.createNewFile())  {
					  System.out.println("File " + file.getName() + " created successfully.");  

		}
		else {
			System.out.println("file already exists");
			
		}}
		catch (IOException e ) {
			System.out.println("exception is there "+e);
		}
	}

}
