package FileHandling;
import java.io.*;
import java.io.Reader;
import java.io.File;   
import java.io.FileNotFoundException;   
import java.util.Scanner; 
public class ReadFile {
	public static void main(String[] args) {
		try {
			File file = new File("sample1.txt"); 
			Scanner dataReader = new Scanner(file);
			while (dataReader.hasNextLine()) {  

                String fileData = dataReader.nextLine();  

                System.out.println(fileData); 
			}
			dataReader.close();  

        } catch (FileNotFoundException exception) {  

            System.out.println("EXCEPTION");
	}
	}

}
