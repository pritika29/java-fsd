package waitsleep;

public class SleepWait {
	//creating an instance of object wse
	private static Object wse = new Object();
	
	//this will cause an interruption so we will use handling InterruptedException in main method
	public static void main(String[] args) throws InterruptedException {
		// pause process for 1 seconds 
		Thread.sleep(1000);
		//pass a statement to make it clear about what step is taken so print a statement
		System.out.println(Thread.currentThread().getName()+" Thread is woken after two second");
		//creating synchronization for object from which we call Wait() method  
        synchronized (wse)    
        {   
            // now we will use wait() method to set wse in waiting state for one seconds  
            wse.wait(1000);   
  
            System.out.println(wse + " Object was in waiting state and woken after one seconds");   
		
		

	}

}}
