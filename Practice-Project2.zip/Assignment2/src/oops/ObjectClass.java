//a program in Java to demonstrate the uses of classes, objects, and the object-oriented pillars in Java

package oops;

public class ObjectClass {
	String Name;
	  int Age;
	  String Gender;
	  ObjectClass(String name, int age,String gender) 
	  {
	    this.Name = name;
	    this.Age = age;
	    this.Gender = gender;}

	public static void main(String[] args) {
		// main class 
		//creating object
		ObjectClass obj1 = new ObjectClass("Ashish dogra", 25, "Male");
		ObjectClass obj2 = new ObjectClass("Ashi singh", 23, "Female");
	    System.out.println("Name: " + obj1.Name);
	    System.out.println("Age: " + obj1.Age);
	    System.out.println("Gender: "+obj1.Gender);
	    System.out.println("Name: " + obj2.Name);
	    System.out.println("Age: " + obj2.Age);
	    System.out.println("Gender: "+obj2.Gender);

	}

}
