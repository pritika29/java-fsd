package oops;

abstract class Abstaraction {
	abstract void run();
}
class Abs1 extends Abstaraction{
	void run() {
		System.out.println("class of abstarction");
	}
	public static void main(String[] args)
	{
		Abstaraction obj= new Abs1();
		
		obj.run();
		
	}
}
