package oops;
//object oriented pillars are 
//inheritance
//encapsulation
//abstraction
//Polymorphism

public class Inheritance {
	//parent class
	void meth1(){}
	void meth2(){}
//child class or driver class
	class Inheritance1 extends Inheritance{
	void meth3(){}
	void met4(){}
	
}}
	
	
	
