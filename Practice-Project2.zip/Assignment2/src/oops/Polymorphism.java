package oops;
//2 methods yet it will run and compile successfully
//Polymorphism
public class Polymorphism {
	//overload
	//two parameters
	public int sum(int a,int b) {
		return(a+b);
	}
	//overload sum()
	//3 parameters
	public int sum(int a,int b, int c) {
		return(a+b+c);
		
	}
	//driver code
	public static void main(String[] args) {
		Polymorphism p=new Polymorphism();
		System.out.println(p.sum(20, 40));
		System.out.println(p.sum(20, 40, 60));
	}
}
