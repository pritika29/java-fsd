package oops;

 public class Encapsulation {
	//private data number
	 private String name;
	 //getter method for name;
	 public String getName() {
		 return name;
	 }//setter method
	 public void setName(String name) {
		 this.name=name;
	 }
	

}
