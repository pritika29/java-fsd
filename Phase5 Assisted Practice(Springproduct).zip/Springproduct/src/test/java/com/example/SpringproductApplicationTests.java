package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringproductApplicationTests {

	@Test
	void contextLoads() {
	}

}
