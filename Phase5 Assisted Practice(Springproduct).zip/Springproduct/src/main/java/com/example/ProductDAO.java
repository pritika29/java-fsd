package com.example;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//crud operation layer which has the dao 
@Service
public class ProductDAO {
	
	//autowire - automatically trigger the object creation (no need to write ProductRepository repo=new ProductRepository())
	@Autowired
	ProductRepository repo;
	
//insert
	public ProductDAO(Product product) {
		return;
	}

	
//retrieve	
	public List<Product> getall(){
		return repo.findAll();
	}


	public Product insert(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

}
