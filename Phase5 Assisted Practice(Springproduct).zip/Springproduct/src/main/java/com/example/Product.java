package com.example;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
@Entity
@Data
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int pid;
	private String pname;
	private int cost;
	
	public String setPname() {
		return pname;
	}
	
	
	public int setCost(int i) {
		return cost;
	}


	public void setPname(String parameter) {
		// TODO Auto-generated method stub
		
	}


	public String getPname() {
		// TODO Auto-generated method stub
		return null;
	}


	public String getCost() {
		// TODO Auto-generated method stub
		return null;
	}

}




 

