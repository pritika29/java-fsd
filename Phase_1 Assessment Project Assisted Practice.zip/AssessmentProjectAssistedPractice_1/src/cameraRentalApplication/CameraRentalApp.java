//             CAMERA RENTAL APPLICATION

//LOGIN USERNAME=   Name
//LOGIN Password=   password

package cameraRentalApplication;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//COLLECTING AND CREATING CAMER_A DETAILS

class CameraAttributes {
   private String Camera_ID;
   private String Camera_Brand;
   private String Camera_Model;
   private double Rental_Price;
   private boolean Rented;

   public CameraAttributes(String camera_Id, String camera_brand, String camera_model, double rental_price) {
       this.Camera_ID = camera_Id;
       this.Camera_Brand = camera_brand;
       this.Camera_Model = camera_model;
       this.Rental_Price = rental_price;
       this.Rented = false;
   }

   public double getRentalAmount() {
       return Rental_Price;
   }

   public boolean isRented() {
       return Rented;
   }

   public void setRented(boolean rented) {
       this.Rented = rented;
   }
   public String getCameraId() {
       return Camera_ID;
   }

   public String getBrand() {
       return Camera_Brand;
   }

   public String getModel() {
       return Camera_Model;
   }
}

class User {
   private String Name;
   private String Contact_Number;
   private double Amount_In_Wallet;

   public User(String name, String contactNumber) {
       this.Name = name;
       this.Contact_Number = contactNumber;
       this.Amount_In_Wallet = 0;
   }

   public String getName() {
       return Name;
   }

   public String getContactNumber() {
       return Contact_Number;
   }

   public double getWalletAmount() {
       return Amount_In_Wallet;
   }

   public void setWalletAmount(double wallet_Amount) {
       this.Amount_In_Wallet = wallet_Amount;
   }
}

class CameraRentalApp {
   private List<CameraAttributes> Camera_List;
   private List<User> User_List;
   private Scanner scanner;

   public CameraRentalApp() {
       Camera_List = new ArrayList<>();
       User_List = new ArrayList<>();
       scanner = new Scanner(System.in);
   }

   public void run() {
       int option;
       do {
           displayMenu();
           System.out.print("Enter your choice: ");
           option = scanner.nextInt();
           scanner.nextLine(); // Consume newline character

           switch (option) {
               case 1:
                   addCamera();
                   break;
               case 2:
            	   viewAvailableCameras();
                   break;
               case 3:
                   returnCamera();
                   break;
               case 4:
                  rentCamera();
                   break;
               case 5:
                   viewRentedCameras();
                   break;
               case 6:
                   addUserWalletAmount();
                   break;
               case 7:
                   remove();
               case 8:
                   exit();
                   break;
               default:
                   System.out.println("INVALID CHOICE");
                   break;
           }

           System.out.println();
       } while (option != 8);
   }

   private void remove() {
	// TODO Auto-generated method stub
	   System.out.println("ENTER CAMERA ID");
       String cameraId = scanner.nextLine();
       System.out.println("ENTER CAMERA BRAND:");
       String brand = scanner.nextLine();
       System.out.println("ENTER CAMERA MODEL:");
       String model = scanner.nextLine();
       System.out.println("PRICE PER DAY:");
       double rentalAmount = scanner.nextDouble();
	   scanner.nextLine();
	   Camera_List.remove(new CameraAttributes(cameraId, brand, model, rentalAmount));
       System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLLY REMOVED FROM  THE LIST");
	   
}

private void displayMenu() {
	//WELCOME SECTION FOR CAMERA RENTAL APPLICATION
	//LOG IN PAGE FOR CAMERA RENTAL APPLICATION
  	System.out.println("+******************************************************+") ;
	System.out.println("| WELCOME TO CAMERA RENTAL APPLICATION                 |");
	System.out.println("+******************************************************+\n");
	//LOG IN PAGE FOR CAMERA RENTAL APPLICATION
	System.out.println("LOG IN TO CONTINUE\n");
    
	//TAKING USER INPUT SCANNER IS USED
	Scanner sc= new Scanner(System.in); //System.in is a standard input stream  
    
String User_id, pass;
//ENTER USER NAME AS "  Name  "
//ENTER PASSWORD AS " password  "
	System.out.println("ENTER USER_ID = \n ");
	User_id=sc.nextLine();
	
	System.out.println("ENTER PASSWORD = \n ");
	pass=sc.nextLine();

	if(User_id.equals("Name") && (pass.equals("password"))) {
		System.out.println("LOGIN APPROVED ");
		System.out.println("*************************************************************************************************\n");
	}
			
	else {
		System.out.println("username/password NOT VALID ");
		
		System.out.println("*************************************************************************************************\n");
	}
	

       System.out.println("1. ADD CAMERA");
       System.out.println("2. VIEW CAMERA");
       System.out.println("3. RETURN A CAMERA");
       System.out.println("4. RENT A CAMERA");
       System.out.println("5. VIEW RENTED CAMERAS");
       System.out.println("6. MY WALLET");
       System.out.println("7. REMOVE");
       System.out.println("8. EXIT");
   }

   private void optionsSelection() {
	// TODO Auto-generated method stub
	
}

private void addCamera() {
       System.out.println("ENTER CAMERA ID");
       String cameraId = scanner.nextLine();
       System.out.println("ENTER CAMERA BRAND:");
       String brand = scanner.nextLine();
       System.out.println("ENTER CAMERA MODEL:");
       String model = scanner.nextLine();
       System.out.println("PRICE PER DAY:");
       double rentalAmount = scanner.nextDouble();
       scanner.nextLine(); 

       Camera_List.add(new CameraAttributes(cameraId, brand, model, rentalAmount));
       System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLLY ADDED TO THE LIST");
   }
//TO RENT CAMERA
   private void rentCamera() {
       System.out.println("Enter your name:");
       String name = scanner.nextLine();
       System.out.println("Enter your contact number:");
       String contactNumber = scanner.nextLine();

       User user = getUserByNameAndContactNumber(name, contactNumber);
       if (user == null) {
           user = new User(name, contactNumber);
           User_List.add(user);
       }

       viewAvailableCameras();

       System.out.println("Enter the camera ID you want to rent:");
       String cameraId = scanner.nextLine();

       CameraAttributes selectedCamera = null;
       for (CameraAttributes camera : Camera_List) {
           if (camera.getCameraId().equals(cameraId)) {
               selectedCamera = camera;
               break;
           }
       }

       if (selectedCamera != null && !selectedCamera.isRented()) {
           double rentalAmount = selectedCamera.getRentalAmount();
           if (user.getWalletAmount() >= rentalAmount) {
               selectedCamera.setRented(true);
               user.setWalletAmount(user.getWalletAmount() - rentalAmount);
               System.out.println("Camera rented successfully!");
           } else {
               System.out.println("Insufficient funds in the user's wallet.");
           }
       } else {
           System.out.println("Camera not available for rent.");
       }
   }
   
   
//TO RETURN CAMERA
   private void returnCamera() {
       System.out.println("Enter your name:");
       String name = scanner.nextLine();
       System.out.println("Enter your contact number:");
       String contactNumber = scanner.nextLine();

       User user = getUserByNameAndContactNumber(name, contactNumber);
       if (user == null) {
           System.out.println("User not found.");
           return;
       }

       List<CameraAttributes> rentedCameras = getRentedCamerasByUser(user);
       if (rentedCameras.isEmpty()) {
           System.out.println("No rented cameras found for the user.");
       } else {
           System.out.println("Rented Cameras:");
           for (CameraAttributes camera : rentedCameras) {
               System.out.println(camera.getCameraId() + " - " + camera.getBrand() + " " + camera.getModel());
           }

           System.out.println("Enter the camera ID you want to return:");
           String cameraId = scanner.nextLine();
           CameraAttributes selectedCamera = null;
           for (CameraAttributes camera : rentedCameras) {
               if (camera.getCameraId().equals(cameraId)) {
                   selectedCamera = camera;
                   break;
               }
           }
           if (selectedCamera != null) {
               selectedCamera.setRented(false);
               System.out.println("Camera returned successfully!");
           } else {
               System.out.println("Invalid camera ID.");
           }
       }
   }
   
   
   //ADD AMOUNT TO MY WALLET
   private void addUserWalletAmount() {
       System.out.println("Enter your name:");
       String name = scanner.nextLine();
       System.out.println("Enter your contact number:");
       String contactNumber = scanner.nextLine();
//TAKE USER INPUT ,CONTACT NAME AND DETAILS
       User user = getUserByNameAndContactNumber(name, contactNumber);
       if (user == null) {
           System.out.println("User not found.");
           return;
       }
       System.out.println("Enter the wallet amount to add:");
       double amount = scanner.nextDouble();
       scanner.nextLine(); // Consume newline character

       user.setWalletAmount(user.getWalletAmount() + amount);
       System.out.println("Wallet amount added successfully!");
   }
   
   
   //VIEW CAMERA TO BE TAKEN ON RENT 
   private void viewRentedCameras() {
       System.out.println("Rented Cameras:");
       for (CameraAttributes camera : Camera_List) {
           if (camera.isRented()) {
               System.out.println(camera.getCameraId() + " - " + camera.getBrand() + " " + camera.getModel());
           }
       }
   }
// STATUS OF THE CAMERA IF THEY ARE AVAILABLE IR NOT
   private void viewAvailableCameras() {
       System.out.println("Camera Available");
       for (CameraAttributes camera : Camera_List) {
           if (!camera.isRented()) {
               System.out.println(camera.getCameraId()+" - " +camera.getBrand()+ " " +camera.getModel()+
                       "(Rental Amount: " +camera.getRentalAmount() +" per day)");
           }
       }
   }
   
   
   //TAKE USER'S INPUT ,DETAILS ABOUT USER 
   private User getUserByNameAndContactNumber(String name, String contact_Number) {
       for (User user : User_List) {
           if (user.getName().equals(name)&&user.getContactNumber().equals(contact_Number)) {
               return user;
           }
       }
       return null;
   }
   
   
   //MAIN
   public static void main(String[] args) {
       CameraRentalApp application = new CameraRentalApp();
       application.run();}
   
   
//cameras taken on rent
   private List<CameraAttributes> getRentedCamerasByUser(User user) {
       List<CameraAttributes> rented_Cameras = new ArrayList<>();
       for (CameraAttributes camera : Camera_List) {
           if (camera.isRented()) {
               rented_Cameras.add(camera);
           }
       }
       return rented_Cameras;
   }
   
   
   //exist from the application 
   private void exit() {
       System.out.println("Thankyou for visiting ,visit again");
   }}

	